﻿define(
     ({
        widgets: {
            ShareDialog: {
                title: "Общий доступ",
                heading: "Общий доступ к карте",
                url: "Ссылка на карту",
                embed: "Встроить карту",
                extent: "Опубликовать текущий экстент карты",
                size: "Размер (ширина/высота):",
                facebookTooltip: "Facebook",
                twitterTooltip: "Twitter",
                gplusTooltip: "Google Plus",
                emailTooltip: "Электронная почта"
            }
        }
    })
);
