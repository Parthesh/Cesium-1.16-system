﻿define(
     ({
        widgets: {
            ShareDialog: {
                title: "Freigeben",
                heading: "Diese Karte freigeben",
                url: "Karten-Link",
                embed: "Karte einbetten",
                extent: "Aktuelle Kartenausdehnung freigeben",
                size: "Größe (Breite/Höhe):",
                facebookTooltip: "Facebook",
                twitterTooltip: "Twitter",
                gplusTooltip: "Google Plus",
                emailTooltip: "E-Mail"
            }
        }
    })
);
