﻿define(
     ({
        widgets: {
            ShareDialog: {
                title: "Chia sẻ",
                heading: "Chia sẻ bản đồ này",
                url: "Liên kết Bản đồ",
                embed: "Nhúng Bản đồ",
                extent: "Chia sẻ phạm vi bản đồ hiện tại",
                size: "Kích thước (chiều rộng/chiều cao):",
                facebookTooltip: "Facebook",
                twitterTooltip: "Twitter",
                gplusTooltip: "Google Plus",
                emailTooltip: "Email"
            }
        }
    })
);
