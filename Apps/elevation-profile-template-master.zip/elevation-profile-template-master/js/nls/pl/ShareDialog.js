﻿define(
     ({
        widgets: {
            ShareDialog: {
                title: "Udostępnij",
                heading: "Udostępnij tę mapę",
                url: "Łącze do mapy",
                embed: "Osadź mapę",
                extent: "Udostępnij bieżący zasięg mapy",
                size: "Rozmiar (szerokość/wysokość):",
                facebookTooltip: "Facebook",
                twitterTooltip: "Twitter",
                gplusTooltip: "Google Plus",
                emailTooltip: "Adres e-mail"
            }
        }
    })
);
