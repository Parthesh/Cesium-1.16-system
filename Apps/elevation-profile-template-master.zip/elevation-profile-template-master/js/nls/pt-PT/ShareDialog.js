﻿define(
     ({
        widgets: {
            ShareDialog: {
                title: "Partilhar",
                heading: "Partilhar este mapa",
                url: "Ligação do Mapa",
                embed: "Incorporar Mapa",
                extent: "Partilhar a atual extensão de mapa",
                size: "Tamanho (largura/altura):",
                facebookTooltip: "Facebook",
                twitterTooltip: "Twitter",
                gplusTooltip: "Google Plus",
                emailTooltip: "Correio Eletrónico"
            }
        }
    })
);
