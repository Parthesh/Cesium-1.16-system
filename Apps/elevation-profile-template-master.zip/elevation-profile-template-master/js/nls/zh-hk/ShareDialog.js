﻿define(
     ({
        widgets: {
            ShareDialog: {
                title: "分享",
                heading: "共用此地圖",
                url: "地圖連結",
                embed: "嵌入地圖",
                extent: "共用目前地圖範圍",
                size: "大小(寬度/高度):",
                facebookTooltip: "Facebook",
                twitterTooltip: "Twitter",
                gplusTooltip: "Google Plus",
                emailTooltip: "電子郵件"
            }
        }
    })
);
