﻿define(
     ({
        widgets: {
            ShareDialog: {
                title: "Koplietošana",
                heading: "Koplietot šo karti",
                url: "Kartes saite",
                embed: "Iedarināt karti",
                extent: "Koplietot pašreizējās kartes pārklājumu",
                size: "Izmērs (platums/augstums):",
                facebookTooltip: "Facebook",
                twitterTooltip: "Twitter",
                gplusTooltip: "Google Plus",
                emailTooltip: "E-pasts"
            }
        }
    })
);
