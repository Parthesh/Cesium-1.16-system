﻿define(
     ({
        widgets: {
            ShareDialog: {
                title: "مشاركة",
                heading: "مشاركة هذه الخريطة",
                url: "رابط الخريطة",
                embed: "تضمين الخريطة",
                extent: "مشاركة نطاق الخريطة الحالي",
                size: "الحجم (الاتساع/الارتفاع):",
                facebookTooltip: "Facebook",
                twitterTooltip: "Twitter",
                gplusTooltip: "Google Plus",
                emailTooltip: "البريد الإلكتروني"
            }
        }
    })
);
