
glx.texture = {};
